class SolverError(Exception):
    pass